var express = require("express");
var router = express.Router();
const lib = require("../lib/index");
const path = require("path");
const uploadDir = path.join(__dirname, "../images/");
const formidable = require("formidable");
const fs = require("fs-extra");

router.post("/:type/:id", async (req, res, next) => {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  let type = req.params.type;
  let id = req.params.id;
  if (!type || !id)
    res.send({
      code: 30000,
      message: "Dữ liệu không đủ",
    });
  if (!(await fs.pathExists(`${uploadDir}${type}/${id}`)))
    fs.mkdirSync(`${uploadDir}${type}/${id}`, { recursive: true });
  const form = new formidable.IncomingForm();
  // file size limit 100MB. change according to your needs
  form.maxFileSize = 100 * 1024 * 1024;
  form.keepExtensions = true;
  form.multiples = true;
  form.uploadDir = uploadDir;

  // collect all form files and fileds and pass to its callback
  form.parse(req, (err, fields, files) => {
    // when form parsing fails throw error
    if (err) return res.status(500).json({ error: err });

    if (Object.keys(files).length === 0)
      return res.status(400).json({ message: "no files uploaded" });

    // Iterate all uploaded files and get their path, extension, final extraction path
    const filesInfo = Object.keys(files).map((key) => {
      const file = files[key];
      const filePath = file.path;
      const fileExt = path.extname(file.name);
      const fileName = path.basename(file.name, fileExt);

      return { filePath, fileExt, fileName };
    });

    // // Check whether uploaded files are zip files
    // const validFiles = filesInfo.every(({ fileExt }) => fileExt === ".zip");

    // // if uploaded files are not zip files, return error
    // if (!validFiles)
    //   return res.status(400).json({ message: "unsupported file type" });

    res.status(200).json({ uploaded: true });

    // // iterate through each file path and extract them
    // filesInfo.forEach(({ filePath, fileName }) => {
    //   // create directory with timestamp to prevent overwrite same directory names
    //   // pass deleteSource = true if source file not needed after extraction
    //   extractZip(filePath, extractDir, false);
    // });
  });

  // runs when new file detected in upload stream
  form.on("fileBegin", function (name, file) {
    // get the file base name `index.css.zip` => `index.html`
    const fileName = path.basename(file.name, path.extname(file.name));
    const fileExt = path.extname(file.name);
    // create files with timestamp to prevent overwrite same file names
    file.path = path.join(`${uploadDir}${type}/${id}`, `${fileName}${fileExt}`);
  });
});
module.exports = router;
