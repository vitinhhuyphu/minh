var express = require("express");
var router = express.Router();
const lib = require("../lib/index");

router.get("/list", function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  res.send({
    code: 20000,
    data: {
      total: 20,
      items: [
        {
          order_no: "CcBcFBe7-A9Dc-99Be-C4C1-6B25Bc1F51fC",
          timestamp: 407687145509,
          username: "Scott Brown",
          price: 13135.6,
          status: "pending",
        },
        {
          order_no: "e5eee8eB-85d5-C7EC-bFdC-AF1C26EcEb13",
          timestamp: 407687145509,
          username: "William Jackson",
          price: 13652.2,
          status: "pending",
        },
        {
          order_no: "e5F6BB2B-C68A-f269-2FF5-15E8eB5C6AF7",
          timestamp: 407687145509,
          username: "Jason Johnson",
          price: 9497,
          status: "success",
        },
        {
          order_no: "8ECAeA02-F398-EdBd-FD9A-B15be6Ede0AC",
          timestamp: 407687145509,
          username: "Christopher Martinez",
          price: 1702.6,
          status: "success",
        },
        {
          order_no: "d88DBCEF-95AE-aCc7-89DA-FAFCEcb63eD1",
          timestamp: 407687145509,
          username: "Sandra Moore",
          price: 1444.5,
          status: "success",
        },
        {
          order_no: "66daAd8A-1B13-A53E-D7e8-E84Ad562d6b6",
          timestamp: 407687145509,
          username: "Kenneth Thomas",
          price: 9108.68,
          status: "success",
        },
        {
          order_no: "FB031CDF-E4Fe-91B8-CCC5-A2ffDe40D5Ed",
          timestamp: 407687145509,
          username: "Karen Smith",
          price: 12838.75,
          status: "success",
        },
        {
          order_no: "EcE2FBdA-cAAF-E16F-127E-FA06F722c592",
          timestamp: 407687145509,
          username: "Lisa Garcia",
          price: 2667,
          status: "pending",
        },
        {
          order_no: "722C4cAB-462C-2d7e-BcF7-448c3eaC9C3B",
          timestamp: 407687145509,
          username: "Mary Martin",
          price: 13664,
          status: "success",
        },
        {
          order_no: "edA0Cf94-bbeF-ffd3-DBBC-ED5C04dD855d",
          timestamp: 407687145509,
          username: "Margaret Taylor",
          price: 10776,
          status: "success",
        },
        {
          order_no: "C1c12dBf-aE2C-075F-AD18-572AFEDDFf7f",
          timestamp: 407687145509,
          username: "Kenneth Taylor",
          price: 3857.3,
          status: "success",
        },
        {
          order_no: "6DD77cDd-c1d8-fde9-53bE-6ce1e2C6b295",
          timestamp: 407687145509,
          username: "Kevin Clark",
          price: 7071.8,
          status: "success",
        },
        {
          order_no: "e298CC86-F5cE-DBe5-8bEe-1eaec1cff235",
          timestamp: 407687145509,
          username: "David Walker",
          price: 11187.2,
          status: "success",
        },
        {
          order_no: "DcedCD4c-bDee-f8Da-5c13-F16F11141ccB",
          timestamp: 407687145509,
          username: "Michael Lee",
          price: 4930.85,
          status: "pending",
        },
        {
          order_no: "BF5eB5cB-dcF4-8e9B-B39b-acd9ACD943d4",
          timestamp: 407687145509,
          username: "Amy Hernandez",
          price: 12194.4,
          status: "pending",
        },
        {
          order_no: "f390F5Ce-B2F4-E837-7C4C-3c4EAE35d2DE",
          timestamp: 407687145509,
          username: "Dorothy Hernandez",
          price: 14458,
          status: "pending",
        },
        {
          order_no: "4BAbC77F-83dA-E9fA-f494-FAAfb45AcCE5",
          timestamp: 407687145509,
          username: "Betty Williams",
          price: 8780.58,
          status: "pending",
        },
        {
          order_no: "8BFd6b88-4adf-bAc6-3c1b-Bf0F30067b7D",
          timestamp: 407687145509,
          username: "Sarah Lewis",
          price: 13673,
          status: "success",
        },
        {
          order_no: "A2469B27-BDba-cF5D-6f9a-18EAd38bE1BD",
          timestamp: 407687145509,
          username: "Patricia Lopez",
          price: 12054,
          status: "success",
        },
        {
          order_no: "4cE265b5-2Aa3-8E74-a922-85134bfa83ee",
          timestamp: 407687145509,
          username: "Eric Allen",
          price: 5350,
          status: "pending",
        },
      ],
    },
  });
});

module.exports = router;
