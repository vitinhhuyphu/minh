var express = require("express");
var router = express.Router();
const shortid = require("shortid");
const lib = require("../lib/index");


router.post("/updateVariable", function (req, res, next) {
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    let id = req.body.id
    let variableName = req.body.variableName
    let value = req.body.value
    if(typeof id === 'string' && value!=null && typeof variableName === 'string' && id.length > 2 && variableName.length>2 ){
        lib.saveVariableTemplate(domain,id,variableName,value)
        res.send({
            code:20000
        })
    }else{
        res.send({
            code:30000,
            message: "Định dạng không đúng"
        })
    }
});

module.exports = router;
