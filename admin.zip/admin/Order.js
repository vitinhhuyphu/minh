var express = require("express");
var router = express.Router();
const shortid = require("shortid");
const lib = require("../lib/index");

router.get("/rows", function (req, res, next) {
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    let items = lib.getOrders(domain);
    let page = parseInt(req.query.page ? req.query.page : 1);
    let limit = parseInt(req.query.limit ? req.query.limit : 20);
    let start = (page - 1) * limit;
    let textSearch = req.query.textSearch ? req.query.textSearch.trim():""
    if(["new","dxn","hdh"].indexOf(req.query.status) > -1){
        items = items.filter(e=>e.status == req.query.status)
    }
    items = items.filter(e=>
        e.id.indexOf(textSearch) >= 0 ||
        e.phone.split(" ").join("").indexOf(textSearch.split(" ").join("")) >= 0 ||
        e.name.toUrlFormat().indexOf(textSearch.toUrlFormat()) >= 0 ||
        e.note && e.note.toUrlFormat().indexOf(textSearch.toUrlFormat()) >= 0 ||
        e.address && e.address.toUrlFormat().indexOf(textSearch.toUrlFormat()) >= 0 ||
        e.wardName && e.wardName.toUrlFormat().indexOf(textSearch.toUrlFormat()) >= 0 ||
        e.districtName && e.districtName.toUrlFormat().indexOf(textSearch.toUrlFormat()) >= 0 ||
        e.provinceName && e.provinceName.toUrlFormat().indexOf(textSearch.toUrlFormat()) >= 0
    )
    let list = Array.from(items.sort((a, b) => b.date - a.date).slice(start, start + limit), (e) => {
        return e
    });
    res.send({
        code: 20000,
        data: {
            total: items.length,
            items: list,
        },
    });
});
router.post("/updateStatus", function (req, res, next) {
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    let items = lib.getOrders(domain);
    let item = items.find(e => e.id == req.body.id)
    if (!item || !(req.body.status == "dxn" || req.body.status == "hdh"))
        return res.send({
            code: 30000,
            message:"Định dạng dữ liệu không đúng"
        });
    else{
        item.status = req.body.status
        return res.send({
            code: 20000
        });
    }
});

module.exports = router;