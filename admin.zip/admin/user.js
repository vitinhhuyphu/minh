var express = require("express");
var router = express.Router();
const shortid = require("shortid");
const lib = require("../lib/index");

router.post("/login", function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  res.send({
    code: 20000,
    data: {
      roles: ["admin"],
      introduction: "I am a super administrator",
      avatar:
        "https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif",
      name: "Super Admin",
    },
  });
});

router.get("/info", function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  res.send({
    code: 20000,
    data: {
      roles: ["admin"],
      introduction: "I am a super administrator",
      avatar:
        "https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif",
      name: "Super Admin",
    },
  });
});

router.get("/rows", function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  let items = lib.getUsers()
  let list = Array.from(items,e=>{
    return {
      id:e.id,
      username:e.username,
      status:e.status,
      fullname:e.fullname,
      phone:e.phone
    }
  })
  res.send({
    code: 20000,
    data: {
      total: list.length,
      items: list,
    },
  });
});

router.get("/getById/:id", function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  let items = lib.getUsers()
  let item = items.find((e) => e.id == req.params.id);
  if (!item) {
    res.send({
      code: 30000,
      message: "Không tìm thấy dữ liệu bạn cần",
    });
    return;
  }
  res.send({
    code: 20000,
    data: {
      id: item.id,
      username: item.username,
      fullname: item.fullname,
      phone: item.phone,
      email: item.email,
      status: item.status,
      logs: item.logs,
      note: item.note,
    },
  });
});

var specialChars = "<>@!#$%^&*()_+[]{}?:;|'\"\\,./~`-=";
function checkForSpecialChar(string) {
  for (let i = 0; i < specialChars.length; i++) {
    if (string.indexOf(specialChars[i]) > -1) {
      return true;
    }
  }
  return false;
}
function checkUser(item) {
  let items = lib.getUsers()
  if (!item) return "Dữ liệu Null";
  if (!item.username || item.username.length > 20 || item.username.length < 4)
    return "Tên đang nhập không đúng định dạng";
  if (checkForSpecialChar(item.username))
    return "Tên đang nhập không đúng định dạng";
  if (!item.fullname || item.fullname.length > 20 || item.fullname.length < 4)
    return "Tên người dùng không đúng định dạng";
  if (
    !item.id &&
    (item.pass != item.checkPass ||
      item.pass.length > 20 ||
      item.pass.length < 6)
  )
    return "Mật khẩu chưa đúng định dạng";
  if (!item.id && items.findIndex((e) => e.username == item.username) > -1)
    return "Tên đăng nhập đã tồn tại vui lòng chọn tên khác";
  if(["HD","CD","NHD","Delete"].indexOf(item.status)==-1) return "Dữ liệu không đúng"
  return "";
}
router.post("/update", function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  let items = lib.getUsers()
  let err = checkUser(req.body);
  if (err) {
    res.send({
      code: 30000,
      message: err,
    });
    return;
  }
  let item = items.find(e=>e.id == req.body.id)||{};
  if (!item.id) {
    item.id = shortid.generate();
    items.push(item);
    item.logs = [{ date: Date.now(), mes: "được tạo mới bởi Admin" }];
  } else {
    if (!Array.isArray(item.logs)) item.logs = [];
    item.logs.push({ date: Date.now(), mes: "được cập nhật bởi Admin" });
  }
  item.__Doc = "User";
  item.username = req.body.username;
  item.fullname = req.body.fullname;
  item.phone = req.body.phone;
  item.email = req.body.email;
  if(req.body.pass) item.pass = req.body.pass;
  item.status = req.body.status;
  item.note = req.body.note;

  res.send({
    code: 20000,
    data: {
      id: item.id,
    },
  });
});

module.exports = router;
