var express = require("express");
var router = express.Router();
const lib = require("../lib/index");
const shortid = require("shortid");

router.post("/saveDatabase", function (req, res, next) {
  lib.saveDatabase();
  res.send({
    code: 20000,
  });
});

router.post("/backup", function (req, res, next) {
  lib.backup(
    function (name) {
      res.send({
        code: 20000,
        data: name,
      });
    },
    function (err) {
      res.send({
        code: 30000,
        message: err,
      });
    }
  );
});

router.get("/rows", function (req, res, next) {
  res.send({
    code: 20000,
    data: {
      items: lib.getBackUpFiles(),
    },
  });
});

router.post("/remove", function (req, res, next) {
  let fileName = req.body.filename;
  lib
    .removeBackUpFile(fileName)
    .then((_) => {
      res.send({
        code: 20000,
      });
    })
    .catch((err) => {
      res.send({
        code: 30000,
        message: err,
      });
    });
});

router.post("/loadDatabase", function (req, res, next) {
  lib.load()
  res.send({
    code: 20000,
  });
});

router.get("/generate-id", function (req, res, next) {
  res.send({
    code: 20000,
    id: shortid.generate()
  });
});

router.post("/changeDevDomain", function (req, res, next) {
  lib.devDomain = req.body.devDomain
  res.send({
    code: 20000,
  });
});

module.exports = router;
