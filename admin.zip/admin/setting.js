var express = require("express");
var router = express.Router();
const lib = require("../lib/index");
const shortid = require("shortid");

router.post("/saveDatabase", function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  lib.saveDatabase();
  res.send({
    code: 20000,
  });
});

router.post("/backup", function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  lib.backup(
    function (name) {
      res.send({
        code: 20000,
        data: name,
      });
    },
    function (err) {
      res.send({
        code: 30000,
        message: err,
      });
    }
  );
});

router.get("/rows", function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  res.send({
    code: 20000,
    data: {
      items: lib.getBackUpFiles(),
    },
  });
});

router.post("/remove", function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  let fileName = req.body.filename;
  lib
    .removeBackUpFile(fileName)
    .then((_) => {
      res.send({
        code: 20000,
      });
    })
    .catch((err) => {
      res.send({
        code: 30000,
        message: err,
      });
    });
});

router.post("/loadDatabase", function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  lib.load()
  res.send({
    code: 20000,
  });
});

router.get("/generate-id", function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  res.send({
    code: 20000,
    id: shortid.generate()
  });
});

module.exports = router;
