var express = require("express");
var router = express.Router();
const shortid = require("shortid");
const lib = require("../lib/index");

router.get("/rows", function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  let items = lib.getProductCategorys();
  let page = parseInt(req.query.page ? req.query.page : 1);
  let limit = parseInt(req.query.limit ? req.query.limit : 20);
  let start = (page - 1) * limit;
  let list = Array.from(items.slice(start, start + limit), (e) => {
    return {
      id: e.id,
      image: e.image,
      name: e.name,
      status: e.status,
      parentId:e.parentId,
      ordering:e.ordering
    };
  });
  res.send({
    code: 20000,
    data: {
      total: items.length,
      items: list,
    },
  });
});

router.get("/getById/:id", function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  let items = lib.getProductCategorys();
  let item = items.find((e) => e.id == req.params.id);
  if (!item) {
    res.send({
      code: 30000,
      message: "Không tìm thấy dữ liệu bạn cần",
    });
    return;
  }
  res.send({
    code: 20000,
    data: item,
  });
});

function checkProductCategory(item) {
  if (!item|| !item.id) return "Dữ liệu Null";
  if (!item.name || item.name.length > 100 || item.name.length < 10)
    return "Tên sản phẩm không đúng định dạng";
  if (["HD", "CD", "NHD", "Delete"].indexOf(item.status) == -1)
    return "Dữ liệu không đúng";
  return "";
}
router.post("/update", function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  let err = checkProductCategory(req.body);
  if (err) {
    res.send({
      code: 30000,
      message: err,
    });
    return;
  }
  let items = lib.getProductCategorys();
  let item = items.find((e) => e.id == req.body.id)|| {}
  if (!item.id) {
    item.id = req.body.id;
    items.push(item);
    item.logs = [{ date: Date.now(), mes: "được tạo mới bởi Admin" }];
  } else {
    if (!Array.isArray(item.logs)) item.logs = [];
    item.logs.push({ date: Date.now(), mes: "được cập nhật bởi Admin" });
  }

  item.__Doc = "ProductCategory";
  if (req.body.name) item.name = req.body.name;
  if (req.body.categoryId) item.categoryId = req.body.categoryId;
  if (req.body.title) item.title = req.body.title;
  if (req.body.slug) item.slug = req.body.slug;
  if (req.body.description != null) item.description = req.body.description;
  if (req.body.status) item.status = req.body.status;
  if (req.body.isHome) item.isHome = req.body.isHome == true ? true : false;
  if (req.body.image != null) item.image = req.body.image;
  if (req.body.ogImage != null) item.ogImage = req.body.ogImage;
  if (req.body.note != null) item.note = req.body.note;
  if (req.body.content != null) item.content = req.body.content;
  item.date = Date.now();

  res.send({
    code: 20000,
    data: {
      id: item.id,
    },
  });
});

module.exports = router;
