var express = require("express");
var router = express.Router();
const lib = require("../lib/index");
const path = require("path");
const dir = path.join(__dirname, "../images/");
const formidable = require("formidable");
const fs = require("fs-extra");
router.post("/remove", function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  let type = req.body.type;
  let id = req.body.id;
  let filename = req.body.filename;
  if (!type || !id || !filename)
    res.send({
      code: 20000,
      message: "Dữ liệu không đủ",
    });
  console.log(`${dir}${type}/${id}/${filename}`);
  fs.remove(`${dir}${type}/${id}/${filename}`)
    .then((rs) => {
      res.send({
        code: 20000,
      });
    })
    .catch((err) => {
      res.send({
        code: 3000,
        message: err,
      });
    });
});
router.post("/rows",async function (req, res, next) {
  let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
  let type = req.body.type;
  let id = req.body.id;
  if (!type || !id)
    res.send({
      code: 20000,
      message: "Dữ liệu không đủ",
    });
  res.send({
    code: 20000,
    data: {
      items: await getFiles(`${dir}${type}/${id}`),
    },
  });
});
async function getFiles(dir, files_) {
  files_ = files_ || [];
  if (await fs.pathExists(dir)) {
    var files = fs.readdirSync(dir);
    for (var i in files) {
      var name = dir + "/" + files[i];
      if (!fs.statSync(name).isDirectory()) {
        files_.push(files[i]);
      }
    }
  }
  return files_;
}
module.exports = router;
