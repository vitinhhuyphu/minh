var express = require('express');
var router = express.Router();
const lib = require("../lib");
const business = require("./business")
var MobileDetect = require('mobile-detect')
/* GET home page. */
router.get('/', function (req, res, next) {
    let start = Date.now()
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    if (!lib.cache[domain + "home"] || !lib.cache[domain + "home"].desktopTemp || !lib.cache[domain + "home"].mobileTemp || lib.cache[domain + "home"].timeCache < Date.now() || req.query.clear == "") {
        let website = Object.assign({}, business.getDataForLayout(domain))
        let compoments = business.getHomeCompoment(domain)
        website.compoments = compoments
        lib.cache[domain + "home"] = website
        website.timeCache = Date.now() + 1000 * 60 * 60 * 24
    }
    let md = new MobileDetect(req.headers['user-agent']);
    let isMobile = req.query.mobile ? true : (md.mobile() ? true : false)
    let viewFile = (isMobile ? lib.cache[domain + "home"].mobileTemplateId : lib.cache[domain + "home"].desktopTemplateId) + '/index'
    console.log(Date.now() - start, domain, viewFile, lib.cache[domain + "home"].desktopTemp)
    if(!lib.cache[domain + "home"].desktopTemp || !lib.cache[domain + "home"].mobileTemp) res.render("error");
    else res.render(viewFile, lib.cache[domain + "home"]);
});

/* GET ProductCatelogy page. */
router.get('/:slug', function (req, res, next) {
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    if (!lib.cache[domain + req.params.slug] || !lib.cache[domain + req.params.slug].desktopTemp || !lib.cache[domain + req.params.slug].mobileTemp || lib.cache[domain + req.params.slug].timeCache < Date.now() || req.query.clear == "") {
        let website = Object.assign({}, business.getDataForLayout(domain))
        let catelogy = Object.assign({}, lib.getProductCategorys(domain).find(e => e.slug == req.params.slug))
        let catelogyParent = lib.getProductCategorys(domain).find(e => e.id == catelogy.parentId)
        if (catelogyParent) {
            catelogy.catelogyParent = {
                name: catelogyParent.name,
                slug: catelogyParent.slug
            }
        }
        catelogy.products = lib.getProducts(domain).filter(e => e.categoryId == catelogy.id && e.status == "HD").sort((a, b) => a.ordering || 0 - b.ordering || 0)
        website.catelogy = catelogy

        lib.cache[domain + req.params.slug] = website
        website.timeCache = Date.now() + 1000 * 60 * 60 * 24
    }
    let md = new MobileDetect(req.headers['user-agent']);
    let isMobile = req.query.mobile ? true : (md.mobile() ? true : false)
    let viewFile = (isMobile ? lib.cache[domain + req.params.slug].mobileTemplateId : lib.cache[domain + req.params.slug].desktopTemplateId) + '/ProductCategory'
    if(!lib.cache[domain + req.params.slug].desktopTemp || !lib.cache[domain + req.params.slug].mobileTemp) res.render("error");
    else res.render(viewFile, lib.cache[domain + req.params.slug]);
});
/* GET Product page. */
router.get('/:slug/:productSlug', function (req, res, next) {
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    if (!lib.cache[domain + req.params.slug + req.params.productSlug] || !lib.cache[domain + req.params.slug + req.params.productSlug].desktopTemp || !lib.cache[domain + req.params.slug + req.params.productSlug].mobileTemp || lib.cache[domain + req.params.slug + req.params.productSlug].timeCache < Date.now() || req.query.clear == "") {
        let website = Object.assign({}, business.getDataForLayout(domain))
        let catelogy = Object.assign({}, lib.getProductCategorys(domain).find(e => e.slug == req.params.slug))
        let product = Object.assign({}, lib.getProducts(domain).find(e => e.slug == req.params.productSlug))
        let brand = Object.assign({
            name: "No Brand"
        }, lib.getBrands(domain).find(e => e.id == product.brandId))
        let productInvolves = lib.getProducts(domain).filter(e => e.categoryId == product.categoryId && e.id != product.id && e.status == "HD").sort((a, b) => a.ordering || 0 - b.ordering || 0).slice(0, 5)
        website.catelogy = catelogy
        website.product = product
        website.brand = brand
        website.productInvolves = productInvolves
        if (productInvolves.length < 5) {
            console.log(productInvolves.length)
            let pros = lib.getProducts(domain).filter(e => e.id != product.id && e.status == "HD").sort((a, b) => a.ordering || 0 - b.ordering || 0).slice(0, 5 - productInvolves.length)
                .forEach(e => {
                    productInvolves.push(e)
                });
        }
        lib.cache[domain + req.params.slug + req.params.productSlug] = website
        website.timeCache = Date.now() + 1000 * 60 * 60 * 24
    }
    let md = new MobileDetect(req.headers['user-agent']);
    let isMobile = req.query.mobile ? true : (md.mobile() ? true : false)
    let viewFile = (isMobile ? lib.cache[domain + req.params.slug + req.params.productSlug].mobileTemplateId : lib.cache[domain + req.params.slug + req.params.productSlug].desktopTemplateId) + '/Product'
    if(!lib.cache[domain + req.params.slug+ req.params.productSlug].desktopTemp || !lib.cache[domain + req.params.slug+ req.params.productSlug].mobileTemp) res.render("error");
    else res.render(viewFile, lib.cache[domain + req.params.slug + req.params.productSlug]);
});

module.exports = router;