var express = require('express');
var router = express.Router();
const lib = require("../lib");
const business = require("./business")
var MobileDetect = require('mobile-detect')
/* GET home page. */
router.get('/', function (req, res, next) {
    let start = Date.now()
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    if (!lib.cache[domain + "home"] || !lib.cache[domain + "home"].desktopTemp || !lib.cache[domain + "home"].mobileTemp || lib.cache[domain + "home"].timeCache < Date.now() || req.query.clear == "") {
        let website = Object.assign({}, business.getDataForLayout(domain))
        let compoments = business.getHomeCompoment(domain)
        website.compoments = compoments

        //seo
        website.canonical = website.subDomain + domain
        website.title = website.siteTitle

        lib.cache[domain + "home"] = website
        website.timeCache = Date.now() + 1000 * 60 * 60 * 24
    }
    let md = new MobileDetect(req.headers['user-agent']);
    let isMobile = req.query.mobile ? true : (md.mobile() ? true : false)
    let viewFile = (isMobile ? lib.cache[domain + "home"].mobileTemplateId : lib.cache[domain + "home"].desktopTemplateId) + '/index'
    console.log(Date.now() - start, domain, viewFile, !lib.cache[domain + "home"].desktopTemp || !lib.cache[domain + "home"].mobileTemp)
    lib.cache[domain + "home"].order = req.session.order||{items:[]}
    if (!lib.cache[domain + "home"].desktopTemp || !lib.cache[domain + "home"].mobileTemp) res.render("error");
    else res.render(viewFile, lib.cache[domain + "home"]);
});

router.get('/thank-you/:orderId', function (req, res, next) {
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    
    let website = Object.assign({}, business.getDataForLayout(domain))

    let order = lib.getOrders(domain).find(e=>e.id == req.params.orderId)
    if(!order) return res.redirect(301, `/tra-cuu-don-hang`)
    if(order.id != req.session.orderId ) return res.redirect(301, `/tra-cuu-don-hang/${order.id}`)
    req.session.orderId = null
    //seo
    website.canonical = website.subDomain + domain
    website.domain = website.subDomain + domain
    website.orderId = req.params.orderId
    website.title = website.siteTitle

    let md = new MobileDetect(req.headers['user-agent']);
    let isMobile = req.query.mobile ? true : (md.mobile() ? true : false)
    let viewFile = (isMobile ? website.mobileTemplateId : website.desktopTemplateId) + '/thankyou'
    website.order = req.session.order||{items:[]}
    if (!website.desktopTemp || !website.mobileTemp) res.render("error");
    else res.render(viewFile, website);
})
router.get('/tra-cuu-don-hang', function (req, res, next) {
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    
    let website = Object.assign({}, business.getDataForLayout(domain))

    //seo
    website.canonical = website.subDomain + domain
    website.domain = website.subDomain + domain
    website.orderId = req.params.orderId
    website.title = website.siteTitle

    let md = new MobileDetect(req.headers['user-agent']);
    let isMobile = req.query.mobile ? true : (md.mobile() ? true : false)
    let viewFile = (isMobile ? website.mobileTemplateId : website.desktopTemplateId) + '/checkorder'
    website.order = req.session.order||{items:[]}
    if (!website.desktopTemp || !website.mobileTemp) res.render("error");
    else res.render(viewFile, website);
})
router.get('/tra-cuu-don-hang/:orderId', function (req, res, next) {
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    let website = Object.assign({}, business.getDataForLayout(domain))

    //seo
    website.canonical = website.subDomain + domain
    website.domain = website.subDomain + domain
    website.title = website.siteTitle
    website.order = req.session.order||{items:[]}
    let order = lib.getOrders(domain).find(e=>e.id == req.params.orderId)
    if(!order) return res.redirect(301, `/tra-cuu-don-hang`)
    website.orderDetail = order

    let md = new MobileDetect(req.headers['user-agent']);
    let isMobile = req.query.mobile ? true : (md.mobile() ? true : false)
    let viewFile = (isMobile ? website.mobileTemplateId : website.desktopTemplateId) + '/OrderInfo'
    if (!website.desktopTemp || !website.mobileTemp) res.render("error");
    else res.render(viewFile, website);
})

/* GET ProductCatelogy page. */
router.get('/:slug', function (req, res, next) {
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    if (!lib.cache[domain + req.params.slug] || !lib.cache[domain + req.params.slug].desktopTemp || !lib.cache[domain + req.params.slug].mobileTemp || lib.cache[domain + req.params.slug].timeCache < Date.now() || req.query.clear == "") {
        let website = Object.assign({}, business.getDataForLayout(domain))
        let catelogy = Object.assign({}, lib.getProductCategorys(domain).find(e => e.slug == req.params.slug))
        let catelogyParent = lib.getProductCategorys(domain).find(e => e.id == catelogy.parentId)
        if (catelogyParent) {
            catelogy.catelogyParent = {
                name: catelogyParent.name,
                slug: catelogyParent.slug
            }
        }
        catelogy.products = lib.getProducts(domain).filter(e => e.categoryId == catelogy.id && e.status == "HD").sort((a, b) => a.ordering || 0 - b.ordering || 0)
        website.catelogy = catelogy

        lib.cache[domain + req.params.slug] = website
        website.timeCache = Date.now() + 1000 * 60 * 60 * 24
    }
    let md = new MobileDetect(req.headers['user-agent']);
    let isMobile = req.query.mobile ? true : (md.mobile() ? true : false)
    let viewFile = (isMobile ? lib.cache[domain + req.params.slug].mobileTemplateId : lib.cache[domain + req.params.slug].desktopTemplateId) + '/ProductCategory'
    lib.cache[domain + req.params.slug].order = req.session.order||{items:[]}
    if (!lib.cache[domain + req.params.slug].desktopTemp || !lib.cache[domain + req.params.slug].mobileTemp) res.render("error");
    else res.render(viewFile, lib.cache[domain + req.params.slug]);
});

/* GET Product page. */
router.get('/:slug/:productSlug', function (req, res, next) {
    let s = Date.now()
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    if (!lib.cache[domain + "san-pham" + req.params.productSlug] || !lib.cache[domain + "san-pham" + req.params.productSlug].desktopTemp || !lib.cache[domain + "san-pham" + req.params.productSlug].mobileTemp || lib.cache[domain + "san-pham" + req.params.productSlug].timeCache < Date.now() || req.query.clear == "") {
        let website = Object.assign({}, business.getDataForLayout(domain))
        let product = Object.assign({}, lib.getProducts(domain).find(e => e.slug == req.params.productSlug))
        let catelogy = Object.assign({}, lib.getProductCategorys(domain).find(e => e.id == product.categoryId))
        let brand = Object.assign({
            name: "No Brand"
        }, lib.getBrands(domain).find(e => e.id == product.brandId))
        let productInvolves = lib.getProducts(domain).filter(e => e.categoryId == product.categoryId && e.id != product.id && e.status == "HD").sort((a, b) => a.ordering || 0 - b.ordering || 0).slice(0, 5)
        website.catelogy = catelogy
        website.product = product
        website.brand = brand
        website.productInvolves = productInvolves
        if (productInvolves.length < 5) {
            lib.getProducts(domain).filter(e => e.id != product.id && e.status == "HD").sort((a, b) => a.ordering || 0 - b.ordering || 0).slice(0, 5 - productInvolves.length)
                .forEach(e => {
                    productInvolves.push(e)
                });
        }
        lib.cache[domain + "san-pham" + req.params.productSlug] = website
        website.timeCache = Date.now() + 1000 * 60 * 60 * 24
    }
    if(lib.cache[domain + "san-pham"+ req.params.productSlug].product.id && lib.cache[domain + "san-pham"+ req.params.productSlug].catelogy.id && req.params.slug != lib.cache[domain + "san-pham"+ req.params.productSlug].catelogy.slug) res.redirect(301, `/${lib.cache[domain + "san-pham"+ req.params.productSlug].catelogy.slug}/${lib.cache[domain + "san-pham"+ req.params.productSlug].product.slug}`)
    let md = new MobileDetect(req.headers['user-agent']);
    let isMobile = req.query.mobile ? true : (md.mobile() ? true : false)
    let viewFile = (isMobile ? lib.cache[domain + "san-pham" + req.params.productSlug].mobileTemplateId : lib.cache[domain + "san-pham" + req.params.productSlug].desktopTemplateId) + '/Product'
    lib.cache[domain + "san-pham" + req.params.productSlug].order = req.session.order||{items:[]}
    console.log(Date.now() - s,`${domain}/${req.params.slug}/${req.params.productSlug}`,viewFile)
    if (!lib.cache[domain + "san-pham" + req.params.productSlug].desktopTemp || !lib.cache[domain + "san-pham" + req.params.productSlug].mobileTemp) res.render("error");
    else res.render(viewFile, lib.cache[domain + "san-pham" + req.params.productSlug]);
});
module.exports = router;