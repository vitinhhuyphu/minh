var express = require("express");
var router = express.Router();
router.use("/he-thong", require("./Systemposts"));
router.use("/danh-muc", require("./Article"));
router.use("/", require("./index"));
module.exports = router;
