var express = require('express');
var router = express.Router();
const lib = require("../lib")
const business = require("./business")
var MobileDetect = require('mobile-detect')
/* GET He Thong page. */
router.get('/:ArticleSlug', function (req, res, next) {
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    if (!lib.cache[ domain + req.params.ArticleSlug] || !lib.cache[domain + req.params.ArticleSlug].desktopTemp || !lib.cache[domain + req.params.ArticleSlug].mobileTemp || lib.cache[ domain + req.params.ArticleSlug].timeCache < Date.now() || req.query.clear == "") {
        let website = Object.assign({}, business.getDataForLayout(domain))
        let article = Object.assign({}, lib.getArticles(domain).find(e => e.slug == req.params.ArticleSlug))
        let catelogy = Object.assign({}, lib.getArticleCategorys(domain).find(e => e.id == article.categoryId))
        website.catelogy = catelogy
        website.article = article
        website.articles = lib.getArticles(domain).filter(e => e.categoryId == catelogy.id && e.status == "HD").sort((a, b) => b.date || 0 - a.date || 0)
        lib.cache[ domain + req.params.ArticleSlug] = website
        website.timeCache = Date.now() + 1000 * 60 * 60 * 24
    }
    let md = new MobileDetect(req.headers['user-agent']);
    let isMobile = req.query.mobile ? true : (md.mobile() ? true : false)
    let viewFile = (isMobile ? lib.cache[ domain + req.params.ArticleSlug].mobileTemplateId : lib.cache[ domain + req.params.ArticleSlug].desktopTemplateId) + '/Systemposts'
    lib.cache[domain + req.params.ArticleSlug].order = req.session.order||{items:[]}
    if(!lib.cache[domain + req.params.ArticleSlug].desktopTemp || !lib.cache[domain + req.params.ArticleSlug].mobileTemp) res.render("error");
    else res.render(viewFile, lib.cache[domain + req.params.ArticleSlug]);
});


module.exports = router;