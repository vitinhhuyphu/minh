var express = require('express');
var router = express.Router();
const lib = require("../lib");
const business = require("./business")
var MobileDetect = require('mobile-detect')
router.get("/", function (req, res, next) {
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    if (!lib.cache[domain + "order"] || !lib.cache[domain + "order"].desktopTemp || !lib.cache[domain + "order"].mobileTemp || lib.cache[domain + "order"].timeCache < Date.now() || req.query.clear == "") {
        let website = Object.assign({}, business.getDataForLayout(domain))
        //seo
        website.canonical = website.subDomain + domain
        website.title = "Giỏ hàng"
        lib.cache[domain + "order"] = website
        website.timeCache = Date.now() + 1000 * 60 * 60 * 24
    }
    let md = new MobileDetect(req.headers['user-agent']);
    let isMobile = req.query.mobile ? true : (md.mobile() ? true : false)
    let viewFile = (isMobile ? lib.cache[domain + "order"].mobileTemplateId : lib.cache[domain + "order"].desktopTemplateId) + '/order'
    req.session.order = req.session.order ? req.session.order : {"address":"abc","districtId":"14","name":"Trần Đình Đoàn","note":"abc","email":"doantd90@gmail.com","payMentType":"bank","phone":"0939786678","provinceId":"zt4VduAECm","shipFee":0,"wardId":"9163","status":"new","items":[]}
    lib.cache[domain + "order"].order = req.session.order
    if (!lib.cache[domain + "order"].desktopTemp || !lib.cache[domain + "order"].mobileTemp) res.render("error");
    else res.render(viewFile, lib.cache[domain + "order"]);
})
router.post("/addtocart", function (req, res, next) {
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    if (!req.session.order) req.session.order = {
        items: []
    }
    let product = lib.getProductCache(domain)[req.body.id]
    if (!product) {
        res.send({
            code: 30000,
            message: "Không tồn tại sản phẩm này"
        })
    } else {
        let productCate = lib.getProductCategorys(domain).find(e => e.id == product.categoryId)
        let p = req.session.order.items.find(e => e.id == product.id)
        if (p) {
            p.count++
        } else {
            req.session.order.items.push({
                id: product.id,
                name: product.name,
                count: 1,
                price: product.price,
                image: product.image,
                slug: product.slug,
                cateSlug: productCate ? productCate.slug : 'san-pham'
            })
        }
        res.send({
            code: 20000,
            cartNumber: req.session.order.items.length
        })
    }
})
router.post("/update", function (req, res, next) {
    req.session.order = {
        address: req.body.address,
        districtId: req.body.districtId,
        name: req.body.name,
        note: req.body.note,
        email: req.body.email,
        payMentType: req.body.payMentType,
        phone: req.body.phone,
        provinceId: req.body.provinceId,
        shipFee: req.body.shipFee,
        wardId: req.body.wardId,
        status: "new",
        date: Date.now(),
        items: [],
    }
    if (Array.isArray(req.body.items))
        req.body.items.forEach(item => {
            req.session.order.items.push({
                count: item.count,
                image: item.image,
                name: item.name,
                note: item.note,
                price: item.price,
                slug: item.slug,
                cateSlug: item.cateSlug
            })
        });

    res.send({
        code: 20000,
        data: req.session.order
    })
})
router.post("/location", function (req, res, next) {
    let locations = lib.getLocations()
    if (req.body.id) {
        res.send({
            code: 20000,
            items: locations.filter(e => e.parentId == req.body.id).sort((a, b) => a.name > b.name ? 1 : -1)
        })
    } else {
        res.send({
            code: 20000,
            items: locations.filter(e => e.parentId == null).sort((a, b) => a.name > b.name ? 1 : -1)
        })
    }
})
router.post("/order", function (req, res, next) {
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    req.session.order = {
        address: req.body.address,
        districtId: req.body.districtId,
        name: req.body.name,
        note: req.body.note,
        email: req.body.email,
        payMentType: req.body.payMentType,
        phone: req.body.phone,
        provinceId: req.body.provinceId,
        shipFee: req.body.shipFee,
        wardId: req.body.wardId,
        domain: domain,
        status: "new",
        date: Date.now(),
        items: [],
        __Doc: "Order"
    }
    if (Array.isArray(req.body.items))
        req.body.items.forEach(item => {
            req.session.order.items.push({
                count: item.count,
                image: item.image,
                name: item.name,
                note: item.note,
                price: item.price,
                slug: item.slug,
                cateSlug: item.cateSlug
            })
        });
    if (req.session.order.items.length > 0) {
        let orders = lib.getOrders(domain)
        let order = Object.assign({}, req.session.order)
        order.id = (`HD` + (1000000 + orders.length)).replace("HD1", "HD")
        req.session.orderId = order.id
        orders.push(order)
        let locations = lib.getLocations()
        if (order.wardId) {
            let ward = locations.find(e => e.id == order.wardId)
            order.wardName = ward ? ward.name : order.wardId
        }
        if (order.districtId) {
            let district = locations.find(e => e.id == order.districtId)
            order.districtName = district ? district.name : order.districtId
        }
        if (order.provinceId) {
            let province = locations.find(e => e.id == order.provinceId)
            order.provinceName = province ? province.name : order.provinceId
        }
        req.session.order.items = []
        res.send({
            code: 20000,
            data: order
        })
    } else {
        res.send({
            code: 30000,
            message: "Vui lòng chọn sản phẩm cần mua",
            data: req.session.order
        })
    }
})
router.post("/check", function (req, res, next) {
    let domain = req.headers.host.indexOf("localhost") > -1 ? lib.devDomain : req.headers.host.split(".s.")[0]
    let text = req.body.text?req.body.text:""
    let orders = lib.getOrders(domain).filter(e=>e.id == text.trim() || e.phone.split(" ").join("") == text.split(" ").join("")).sort((a,b)=>b.date-a.date)
    if(orders.length > 0){
        res.send({
            code:20000,
            data:{
                id:orders[0].id
            }
        })
    }else{
        res.send({
            code:30000,
            message:"Không tìm thấy thông tin đơn hàng, vui lòng kiểm tra lại mã hóa đơn hoặc số điện thoại"
        })
    }
})
module.exports = router;