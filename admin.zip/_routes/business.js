const lib = require("../lib")
function getDataForLayout(domain) {
    let website = Object.assign({}, lib.getWebsiteInfo(domain));
    website.productCategorys = getCataloge()
    website.mobileTemp = lib.getTemplates(domain).find(e=>e.id == website.mobileTemplateId)
    website.desktopTemp = lib.getTemplates(domain).find(e=>e.id == website.desktopTemplateId)
    return website
    function getCataloge() {
        let list = lib.getProductCategorys(domain)
        let items = []
        list.forEach(e => {
            if (!e.parentId) items.push(e)
            else {
                let parent = list.find(x => x.id == e.parentId)
                if (parent) {
                    if (!Array.isArray(parent.items)) parent.items = []
                    parent.items.push(e)
                } else {
                    items.push(e)
                }
            }
        });
        sort(items)

        function sort(items) {
            let list = Array.from(items)
            items.splice(0, items.length)
            list.sort((a, b) => (Number.isInteger(a.ordering) ? a.ordering : 0) - (Number.isInteger(b.ordering) ? b.ordering : 0)).forEach(e => {
                items.push(e)
                if (Array.isArray(e.items)) {
                    sort(e.items)
                }
            })
        }
        return items
    }
}
function getHomeCompoment(domain){
    let catelogys = lib.getProductCategorys(domain).filter(e=>e.isHome && e.status=="HD").sort((a,b)=>(a.ordering||0-b.ordering||0))
    let products = lib.getProducts(domain)
    let items = []
    for (let i = 0; i < catelogys.length; i++) {
        let rows = products.filter(e=>e.categoryId == catelogys[i].id  && e.status=="HD").sort((a,b)=>(a.ordering||0-b.ordering||0)).splice(0,10)
        if(rows.length>5){
            items.push({
                id:catelogys[i].id,
                name:catelogys[i].name,
                slug:catelogys[i].slug,
                items:rows
            })
        }
    }
    return items
}
module.exports = {
    getDataForLayout,
    getHomeCompoment
}